﻿LayoutLoad("default:default_ctl.xml");
LayoutLoad("default:default_msgbox.xml");

